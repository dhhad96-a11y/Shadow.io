let publicConfig = null;
let cloudResellers = [];
let currentUserType = null;
let currentResellerData = null;

const byId = (id) => document.getElementById(id);

async function api(path, options = {}) {
  const response = await fetch(path, {
    credentials: 'same-origin',
    cache: 'no-store',
    ...options,
    headers: {
      ...(options.body ? { 'Content-Type': 'application/json' } : {}),
      ...(options.headers || {})
    }
  });
  let data;
  try { data = await response.json(); } catch { data = {}; }
  if (!response.ok) throw new Error(data.error || `Request failed (${response.status})`);
  return data;
}

function showToast(message) {
  const toast = byId('toast');
  toast.textContent = message;
  toast.classList.add('show');
  setTimeout(() => toast.classList.remove('show'), 3000);
}

function showScreen(screenId) {
  document.querySelectorAll('.screen').forEach((screen) => screen.classList.remove('active'));
  byId(screenId).classList.add('active');
}

function fillPublicConfig() {
  if (!publicConfig) return;
  document.title = publicConfig.brand?.title || document.title;
  const portalName = document.querySelector('.portal-title');
  const portalSubtitle = document.querySelector('.portal-sub');
  const hubName = document.querySelector('.hub-user-info b');
  const hubSubtitle = document.querySelector('.hub-user-info small');
  if (portalName) portalName.textContent = `👑 ${publicConfig.brand?.portalName || 'SHADOW TEAM'}`;
  if (portalSubtitle) portalSubtitle.textContent = publicConfig.brand?.portalSubtitle || 'USER PORTAL';
  if (hubName) hubName.textContent = publicConfig.brand?.hubName || 'SHADOW VIP';
  if (hubSubtitle) hubSubtitle.textContent = publicConfig.brand?.hubSubtitle || 'SHADOW';

  const productSelect = byId('productType');
  productSelect.replaceChildren();
  for (const product of (publicConfig.products || [])) {
    const option = document.createElement('option');
    option.value = product.value;
    option.textContent = product.label;
    productSelect.appendChild(option);
  }

  const validitySelect = byId('validity');
  validitySelect.replaceChildren();
  for (const plan of (publicConfig.plans || [])) {
    const option = document.createElement('option');
    option.value = String(plan.days);
    option.textContent = plan.label;
    validitySelect.appendChild(option);
  }
}

async function loadCloudData() {
  try {
    const result = await api('/api/resellers');
    cloudResellers = Array.isArray(result.resellers) ? result.resellers : [];
    renderResellersUI();
  } catch (error) {
    console.error('Error loading reseller list:', error);
    showToast(error.message);
  }
}

function makeSmallButton(label, action, id, className = 'delete-btn') {
  const button = document.createElement('button');
  button.type = 'button';
  button.className = className;
  button.textContent = label;
  button.addEventListener('click', () => action(id));
  return button;
}

function renderResellersUI() {
  const container = byId('resellerContainer');
  if (!container) return;
  container.replaceChildren();

  if (!cloudResellers.length) {
    const empty = document.createElement('div');
    empty.className = 'list-item';
    empty.textContent = 'No resellers yet';
    container.appendChild(empty);
    return;
  }

  for (const reseller of cloudResellers) {
    const row = document.createElement('div');
    row.className = 'list-item';

    const identity = document.createElement('span');
    const name = document.createElement('b');
    name.textContent = reseller.name;
    identity.appendChild(name);
    if (!reseller.hasPassword) {
      const status = document.createElement('small');
      status.textContent = ' (password required)';
      status.style.color = '#ffb347';
      identity.appendChild(status);
    }

    const actions = document.createElement('div');
    const balance = document.createElement('span');
    balance.textContent = `$${Number(reseller.balance || 0).toFixed(2)}`;
    balance.style.color = '#2ecc71';
    balance.style.marginRight = '8px';
    actions.appendChild(balance);
    actions.appendChild(makeSmallButton('Set Password', setResellerPassword, reseller.firestoreId));
    actions.appendChild(makeSmallButton('Delete', deleteResellerCloud, reseller.firestoreId));
    row.append(identity, actions);
    container.appendChild(row);
  }
}

function openAdminModal() {
  byId('adminModal').classList.add('active');
  byId('adminPassInput').value = '';
  byId('adminError').style.display = 'none';
}

function openResellerModal() {
  byId('resellerModal').classList.add('active');
  byId('resellerUserInput').value = '';
  byId('resellerPassInput').value = '';
  byId('resellerError').style.display = 'none';
}

function closeModal(id) {
  byId(id).classList.remove('active');
}

function showDashboard() {
  showScreen('dashboardScreen');
  renderResellersUI();
  if (currentUserType === 'admin') loadCloudData();
}

async function verifyAdmin() {
  const password = byId('adminPassInput').value;
  try {
    await api('/api/auth', { method: 'POST', body: JSON.stringify({ action: 'admin_login', password }) });
    currentUserType = 'admin';
    byId('adminPassInput').value = '';
    currentResellerData = null;
    byId('panelTitle').textContent = '👑 Control Panel';
    byId('accountBalance').textContent = 'UNLIMITED';
    byId('adminResellerSection').style.display = 'block';
    closeModal('adminModal');
    showDashboard();
  } catch (error) {
    byId('adminError').textContent = error.message;
    byId('adminError').style.display = 'block';
  }
}

async function verifyReseller() {
  const username = byId('resellerUserInput').value.trim();
  const password = byId('resellerPassInput').value;
  try {
    const result = await api('/api/auth', {
      method: 'POST',
      body: JSON.stringify({ action: 'reseller_login', username, password })
    });
    currentUserType = 'reseller';
    byId('resellerPassInput').value = '';
    currentResellerData = result.reseller;
    byId('panelTitle').textContent = `👤 Seller: ${result.reseller.name}`;
    byId('accountBalance').textContent = `$${Number(result.reseller.balance).toFixed(2)}`;
    byId('adminResellerSection').style.display = 'none';
    closeModal('resellerModal');
    showDashboard();
  } catch (error) {
    byId('resellerError').textContent = error.message;
    byId('resellerError').style.display = 'block';
  }
}

async function lockSystem() {
  try { await api('/api/auth', { method: 'POST', body: JSON.stringify({ action: 'logout' }) }); }
  catch (error) { console.warn('Logout request failed:', error); }
  currentUserType = null;
  currentResellerData = null;
  byId('singleKeyBox').style.display = 'none';
  byId('userKeyInput').value = '';
  showScreen('userScreen');
}

async function addReseller() {
  const name = byId('resellerName').value.trim();
  const password = byId('resellerPassword').value;
  const balance = Number(byId('resellerBalance').value);
  try {
    const result = await api('/api/resellers', {
      method: 'POST',
      body: JSON.stringify({ action: 'add', name, password, balance })
    });
    cloudResellers.push(result.reseller);
    renderResellersUI();
    byId('resellerName').value = '';
    byId('resellerPassword').value = '';
    showToast(`✓ Reseller ${name} created`);
  } catch (error) {
    alert(error.message);
  }
}

async function deleteResellerCloud(firestoreId) {
  if (!confirm('Delete this reseller?')) return;
  try {
    await api('/api/resellers', {
      method: 'POST',
      body: JSON.stringify({ action: 'delete', firestoreId })
    });
    cloudResellers = cloudResellers.filter((reseller) => reseller.firestoreId !== firestoreId);
    renderResellersUI();
    showToast('✓ Reseller deleted');
  } catch (error) {
    alert(error.message);
  }
}

async function setResellerPassword(firestoreId) {
  const password = prompt('Enter a new password (at least 8 characters):');
  if (password === null) return;
  try {
    await api('/api/resellers', {
      method: 'POST',
      body: JSON.stringify({ action: 'set_password', firestoreId, password })
    });
    const reseller = cloudResellers.find((item) => item.firestoreId === firestoreId);
    if (reseller) reseller.hasPassword = true;
    renderResellersUI();
    showToast('✓ Reseller password updated');
  } catch (error) {
    alert(error.message);
  }
}

async function buyAndGenerateKey() {
  const productType = byId('productType').value;
  const validityDays = Number(byId('validity').value);
  try {
    const result = await api('/api/keys', {
      method: 'POST',
      body: JSON.stringify({ productType, validityDays })
    });
    byId('generatedKeyText').textContent = result.key;
    byId('singleKeyBox').style.display = 'block';
    if (currentUserType === 'reseller' && currentResellerData) {
      currentResellerData.balance = result.balance;
      byId('accountBalance').textContent = `$${Number(result.balance).toFixed(2)}`;
    }
    showToast('✓ Key generated and saved to Cloud');
  } catch (error) {
    alert(error.message);
  }
}

async function copyGeneratedKey() {
  const value = byId('generatedKeyText').textContent;
  try {
    await navigator.clipboard.writeText(value);
    showToast('Key copied!');
  } catch {
    prompt('Copy key:', value);
  }
}

async function validateKeyLogin() {
  const key = byId('userKeyInput').value.trim();
  if (!key) return alert('Please enter Access Key!');
  try {
    await api('/api/auth', { method: 'POST', body: JSON.stringify({ action: 'key_login', key }) });
    byId('userKeyInput').value = '';
    showScreen('userHubScreen');
  } catch (error) {
    alert(error.message);
  }
}

async function copyHappVpnConfig() {
  try {
    const result = await api('/api/vpn-config');
    const value = JSON.stringify(result.config, null, 2);
    try {
      await navigator.clipboard.writeText(value);
      showToast('✓ Happ VPN (Shadow v3) copied!');
    } catch {
      prompt('Copy Happ VPN Config:', value);
    }
  } catch (error) {
    alert(error.message);
  }
}

window.showToast = showToast;
window.openAdminModal = openAdminModal;
window.openResellerModal = openResellerModal;
window.closeModal = closeModal;
window.verifyAdmin = verifyAdmin;
window.verifyReseller = verifyReseller;
window.lockSystem = lockSystem;
window.addReseller = addReseller;
window.deleteResellerCloud = deleteResellerCloud;
window.buyAndGenerateKey = buyAndGenerateKey;
window.copyGeneratedKey = copyGeneratedKey;
window.validateKeyLogin = validateKeyLogin;
window.copyHappVpnConfig = copyHappVpnConfig;

(async function init() {
  try {
    const response = await fetch('/config.json', { cache: 'no-store' });
    if (!response.ok) throw new Error('Could not load public config.json');
    publicConfig = await response.json();
    fillPublicConfig();
  } catch (error) {
    console.error(error);
    alert('The site configuration could not be loaded. Check public/config.json.');
  }
})();
