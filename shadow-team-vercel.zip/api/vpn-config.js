import { json, methodNotAllowed, requireSession } from '../lib/server.js';

export default async function handler(req, res) {
  if (req.method !== 'GET') return methodNotAllowed(res, ['GET']);
  const session = requireSession(req, res, ['vip']);
  if (!session) return;

  const address = process.env.HAPP_PROXY_ADDRESS || 'proxy-eu.dripwire.cc';
  const port = Number(process.env.HAPP_PROXY_PORT || 443);
  const auth = process.env.HAPP_PROXY_AUTH;
  const serverName = process.env.HAPP_PROXY_SERVER_NAME || address;
  const remarks = process.env.HAPP_REMARKS || 'Shadow v3';

  if (!auth || auth === 'PUT_YOUR_PROXY_AUTH_TOKEN_HERE') {
    return json(res, 503, { error: 'Proxy authentication is not configured on the server' });
  }
  if (!Number.isInteger(port) || port < 1 || port > 65535) {
    return json(res, 500, { error: 'Proxy port is invalid in server configuration' });
  }

  const config = {
    remarks,
    inbounds: [
      {
        listen: '127.0.0.1', port: 10808, protocol: 'socks',
        settings: { auth: 'noauth', udp: true },
        sniffing: { destOverride: ['http', 'tls', 'quic'], enabled: true, routeOnly: false },
        tag: 'socks'
      },
      {
        listen: '127.0.0.1', port: 10809, protocol: 'http',
        sniffing: { destOverride: ['http', 'tls', 'quic'], enabled: true, routeOnly: false },
        tag: 'http'
      }
    ],
    outbounds: [
      {
        protocol: 'hysteria',
        settings: { address, port, version: 2 },
        streamSettings: {
          hysteriaSettings: { auth, version: 2 },
          network: 'hysteria', security: 'tls',
          tlsSettings: { alpn: ['h3'], serverName, show: false },
          finalmask: { quicParams: { disableChromeParrot: true } }
        },
        tag: 'proxy'
      },
      { protocol: 'freedom', tag: 'direct' }
    ],
    routing: {
      domainStrategy: 'AsIs',
      rules: [
        { network: 'tcp', outboundTag: 'proxy' },
        { network: 'udp', outboundTag: 'proxy', port: '10000-10999' }
      ]
    }
  };

  return json(res, 200, { config });
}
