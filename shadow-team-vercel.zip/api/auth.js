import {
  json, methodNotAllowed, getBody, getDb, createSession, clearSession,
  safeEqual, verifyPassword, checkSameOrigin, consumeRateLimit
} from '../lib/server.js';

export default async function handler(req, res) {
  if (req.method === 'GET') {
    return json(res, 200, { authenticated: false });
  }
  if (req.method !== 'POST') return methodNotAllowed(res, ['GET', 'POST']);
  if (!checkSameOrigin(req, res)) return;

  const body = getBody(req);
  const action = String(body.action || '');

  if (action === 'logout') {
    clearSession(req, res);
    return json(res, 200, { ok: true });
  }

  if (action === 'admin_login') {
    try {
      const rate = await consumeRateLimit(getDb(), req, 'admin-login', 8);
      if (!rate.allowed) return json(res, 429, { error: `Too many attempts. Try again in ${rate.retryAfterSeconds} seconds.` });
    } catch (error) {
      console.error('Admin rate-limit check failed:', error);
      return json(res, 500, { error: 'Server is not configured correctly' });
    }
    const configured = process.env.ADMIN_PASSWORD;
    if (!configured || configured.startsWith('CHANGE_THIS')) return json(res, 503, { error: 'Set a real ADMIN_PASSWORD in Vercel Environment Variables' });
    if (typeof body.password !== 'string' || !safeEqual(body.password, configured)) {
      return json(res, 401, { error: 'Incorrect admin password' });
    }
    try {
      createSession(req, res, { role: 'admin', sub: 'admin', name: 'Administrator' });
      return json(res, 200, { ok: true, role: 'admin', name: 'Administrator' });
    } catch (error) {
      return json(res, 500, { error: error.message || 'Could not create session' });
    }
  }

  if (action === 'reseller_login') {
    const username = typeof body.username === 'string' ? body.username.trim().toLowerCase() : '';
    const password = typeof body.password === 'string' ? body.password : '';
    if (!username || !password) return json(res, 400, { error: 'Enter reseller username and password' });
    try {
      const db = getDb();
      const rate = await consumeRateLimit(db, req, 'reseller-login', 12);
      if (!rate.allowed) return json(res, 429, { error: `Too many attempts. Try again in ${rate.retryAfterSeconds} seconds.` });
      const snapshot = await db.collection('resellers').get();
      const match = snapshot.docs.find((doc) => String(doc.data().name || '').trim().toLowerCase() === username);
      if (!match) return json(res, 401, { error: 'Invalid reseller username or password' });
      const data = match.data();
      if (!data.passwordHash) return json(res, 403, { error: 'This reseller needs a password. Ask the admin to set one.' });
      if (!(await verifyPassword(password, data.passwordHash))) {
        return json(res, 401, { error: 'Invalid reseller username or password' });
      }
      createSession(req, res, { role: 'reseller', sub: match.id, name: data.name });
      return json(res, 200, {
        ok: true,
        role: 'reseller',
        reseller: { firestoreId: match.id, name: data.name, balance: Number(data.balance || 0) }
      });
    } catch (error) {
      console.error('Reseller login failed:', error);
      return json(res, 500, { error: 'Server could not verify reseller login' });
    }
  }

  if (action === 'key_login') {
    const key = typeof body.key === 'string' ? body.key.trim() : '';
    if (!key) return json(res, 400, { error: 'Please enter an access key' });
    try {
      const db = getDb();
      const rate = await consumeRateLimit(db, req, 'vip-key-login', 25);
      if (!rate.allowed) return json(res, 429, { error: `Too many attempts. Try again in ${rate.retryAfterSeconds} seconds.` });
      const masterKey = process.env.VIP_MASTER_KEY;
      if (masterKey && safeEqual(key, masterKey)) {
        createSession(req, res, { role: 'vip', sub: 'master-vip', name: 'VIP' });
        return json(res, 200, { ok: true, role: 'vip' });
      }
      const snapshot = await db.collection('keys').where('code', '==', key).limit(1).get();
      if (snapshot.empty) return json(res, 401, { error: 'Invalid or expired key' });
      const data = snapshot.docs[0].data();
      if (data.isActive === false) return json(res, 401, { error: 'This key has been disabled' });
      if (data.expiresAt && typeof data.expiresAt.toDate === 'function' && data.expiresAt.toDate().getTime() < Date.now()) {
        return json(res, 401, { error: 'This key has expired' });
      }
      createSession(req, res, { role: 'vip', sub: snapshot.docs[0].id, name: 'VIP' });
      return json(res, 200, { ok: true, role: 'vip' });
    } catch (error) {
      console.error('Key login failed:', error);
      return json(res, 500, { error: 'Could not verify key. Check server configuration.' });
    }
  }

  return json(res, 400, { error: 'Unknown authentication action' });
}
