import crypto from 'node:crypto';
import { Timestamp, FieldValue } from 'firebase-admin/firestore';
import {
  json, methodNotAllowed, getBody, getDb, requireSession, checkSameOrigin
} from '../lib/server.js';

const PLANS = new Map([
  [1, { days: 1, price: 0.50 }],
  [7, { days: 7, price: 3.00 }],
  [30, { days: 30, price: 10.00 }]
]);
const PRODUCTS = new Set(['Shadow V3', 'Drip Client']);
const CHARS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';

function generateKey() {
  const bytes = crypto.randomBytes(12);
  let raw = '';
  for (const byte of bytes) raw += CHARS[byte % CHARS.length];
  return `SHDW-${raw.slice(0, 4)}-${raw.slice(4, 8)}-${raw.slice(8, 12)}`;
}

export default async function handler(req, res) {
  if (req.method !== 'POST') return methodNotAllowed(res, ['POST']);
  if (!checkSameOrigin(req, res)) return;
  const session = requireSession(req, res, ['admin', 'reseller']);
  if (!session) return;

  const body = getBody(req);
  const productType = String(body.productType || '');
  const validityDays = Number(body.validityDays);
  const plan = PLANS.get(validityDays);
  if (!PRODUCTS.has(productType)) return json(res, 400, { error: 'Invalid product type' });
  if (!plan) return json(res, 400, { error: 'Invalid validity plan' });

  try {
    const db = getDb();
    const newKey = generateKey();
    const keyRef = db.collection('keys').doc(newKey);
    const expiresAt = Timestamp.fromDate(new Date(Date.now() + plan.days * 24 * 60 * 60 * 1000));
    let newBalance = null;

    if (session.role === 'reseller') {
      const resellerRef = db.collection('resellers').doc(session.sub);
      await db.runTransaction(async (transaction) => {
        const resellerDoc = await transaction.get(resellerRef);
        if (!resellerDoc.exists) throw new Error('RESELLER_NOT_FOUND');
        const balance = Number(resellerDoc.data().balance || 0);
        if (balance + 0.000001 < plan.price) throw new Error('INSUFFICIENT_BALANCE');
        newBalance = Math.round((balance - plan.price) * 100) / 100;
        transaction.update(resellerRef, { balance: newBalance });
        transaction.create(keyRef, {
          code: newKey,
          productType,
          validityDays: plan.days,
          price: plan.price,
          resellerId: session.sub,
          createdAt: FieldValue.serverTimestamp(),
          expiresAt,
          isActive: true
        });
      });
    } else {
      await keyRef.create({
        code: newKey,
        productType,
        validityDays: plan.days,
        price: plan.price,
        createdBy: 'admin',
        createdAt: FieldValue.serverTimestamp(),
        expiresAt,
        isActive: true
      });
    }

    return json(res, 201, { ok: true, key: newKey, balance: newBalance, expiresAt: expiresAt.toDate().toISOString() });
  } catch (error) {
    if (error.message === 'INSUFFICIENT_BALANCE') return json(res, 409, { error: 'Insufficient balance' });
    if (error.message === 'RESELLER_NOT_FOUND') return json(res, 404, { error: 'Reseller account not found' });
    console.error('Key generation failed:', error);
    return json(res, 500, { error: 'Could not generate key' });
  }
}
