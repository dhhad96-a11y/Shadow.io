import {
  json, methodNotAllowed, getBody, getDb, requireSession,
  hashPassword, isValidString, checkSameOrigin
} from '../lib/server.js';

export default async function handler(req, res) {
  const session = requireSession(req, res, ['admin']);
  if (!session) return;

  if (req.method === 'GET') {
    try {
      const snapshot = await getDb().collection('resellers').get();
      const resellers = snapshot.docs.map((doc) => {
        const data = doc.data();
        return {
          firestoreId: doc.id,
          name: String(data.name || ''),
          balance: Number(data.balance || 0),
          hasPassword: Boolean(data.passwordHash)
        };
      }).sort((a, b) => a.name.localeCompare(b.name));
      return json(res, 200, { resellers });
    } catch (error) {
      console.error('Could not list resellers:', error);
      return json(res, 500, { error: 'Could not load resellers from Firebase' });
    }
  }

  if (req.method !== 'POST') return methodNotAllowed(res, ['GET', 'POST']);
  if (!checkSameOrigin(req, res)) return;
  const body = getBody(req);
  let db;
  try { db = getDb(); } catch (error) {
    console.error('Firebase initialization failed:', error);
    return json(res, 500, { error: 'Firebase server credentials are not configured' });
  }

  if (body.action === 'add') {
    const name = typeof body.name === 'string' ? body.name.trim() : '';
    const password = typeof body.password === 'string' ? body.password : '';
    const balance = Number(body.balance);
    if (!isValidString(name, 3, 40)) return json(res, 400, { error: 'Username must be 3 to 40 characters' });
    if (password.length < 8 || password.length > 128) return json(res, 400, { error: 'Password must be at least 8 characters' });
    if (!Number.isFinite(balance) || balance < 0 || balance > 1000000) return json(res, 400, { error: 'Invalid starting balance' });
    try {
      const existing = await db.collection('resellers').get();
      const duplicate = existing.docs.some((doc) => String(doc.data().name || '').trim().toLowerCase() === name.toLowerCase());
      if (duplicate) return json(res, 409, { error: 'Username already exists' });
      const passwordHash = await hashPassword(password);
      const docRef = await db.collection('resellers').add({
        name,
        balance: Math.round(balance * 100) / 100,
        passwordHash,
        createdAt: new Date()
      });
      return json(res, 201, {
        ok: true,
        reseller: { firestoreId: docRef.id, name, balance: Math.round(balance * 100) / 100, hasPassword: true }
      });
    } catch (error) {
      console.error('Could not add reseller:', error);
      return json(res, 500, { error: 'Could not save reseller' });
    }
  }

  if (body.action === 'delete') {
    const id = typeof body.firestoreId === 'string' ? body.firestoreId : '';
    if (!isValidString(id, 1, 150)) return json(res, 400, { error: 'Invalid reseller ID' });
    try {
      await db.collection('resellers').doc(id).delete();
      return json(res, 200, { ok: true });
    } catch (error) {
      console.error('Could not delete reseller:', error);
      return json(res, 500, { error: 'Could not delete reseller' });
    }
  }

  if (body.action === 'set_password') {
    const id = typeof body.firestoreId === 'string' ? body.firestoreId : '';
    const password = typeof body.password === 'string' ? body.password : '';
    if (!isValidString(id, 1, 150)) return json(res, 400, { error: 'Invalid reseller ID' });
    if (password.length < 8 || password.length > 128) return json(res, 400, { error: 'Password must be at least 8 characters' });
    try {
      const ref = db.collection('resellers').doc(id);
      const doc = await ref.get();
      if (!doc.exists) return json(res, 404, { error: 'Reseller not found' });
      await ref.update({ passwordHash: await hashPassword(password) });
      return json(res, 200, { ok: true });
    } catch (error) {
      console.error('Could not update reseller password:', error);
      return json(res, 500, { error: 'Could not update reseller password' });
    }
  }

  return json(res, 400, { error: 'Unknown reseller action' });
}
